************************************
For Windows 64 / Visual Studio users
        ******************
    By Far�s Belhadj amsi@up8.edu
           April 24, 2020
************************************

1) Install builds of GL4Dummies as described at:
	https://github.com/noalien/GL4Dummies/tree/master/builds/MSVC_19

2) For this example we used OpenCV 3.4.10, download this release(opencv-3.4.10-vc14_vc15.exe) on:
	https://opencv.org/releases/
   * After unpacking the exe, copy the opencv directory to C:\
   * copy the three DLLs from C:\opencv\build\x64\vc15\bin\ to C:\Windows\System32\

3) Open the sln (VS Solution) file with Visual Studio Community 19, compile and run.


