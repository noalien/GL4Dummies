Under Windows, you should choose one of these IDE :
- Visual Studio Community 2019
- Code::Blocks

Under Visual Studio:
Open the Solution GL4Dummies.sln, compile the Solution (F7) then execute (ctrl-F5)

Under Code::Blocks:
- Open the project GL4Dummies.cbp then compile the libs (do not execute)
- Open the demo gl4dDemo.cbp, compile then execute.
