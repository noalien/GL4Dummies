/*!\file gl4dfFocus.c
 *
 * \brief filre de génération de cartes de focus vers une texture ou l'écran.
 *
 * \author Farès BELHADJ amsi@ai.univ-paris8.fr
 * \date April 21, 2016
 * 
 */
