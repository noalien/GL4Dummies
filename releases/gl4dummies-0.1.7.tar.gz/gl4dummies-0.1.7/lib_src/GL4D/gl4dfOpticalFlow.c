/*!\file gl4dfOpticalFlow.c
 *
 * \brief génération d'une carte d'optical flow à partir d'une paire
 * de textures représentant deux images consécutives d'une meme
 * séquence.
 *
 * \author Farès BELHADJ amsi@ai.univ-paris8.fr
 * \date April 21, 2016
 * 
 */

