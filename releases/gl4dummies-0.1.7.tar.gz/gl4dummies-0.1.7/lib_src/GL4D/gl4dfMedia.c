/*!\file gl4dfMedia.c
 *
 * \brief filres de génération de média vers une texture ou l'écran.
 *
 * \author Farès BELHADJ amsi@ai.univ-paris8.fr
 * \date April 21, 2016
 * 
 */
