/*!\file gl4dfHatching.c
 *
 * \brief filre de Hatching à partir d'une texture ou l'écran vers une
 * texture ou l'écran.
 *
 * \author Farès BELHADJ amsi@ai.univ-paris8.fr
 * \date April 21, 2016
 * 
 */
