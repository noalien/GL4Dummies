/*!\file gl4dh.h
 *
 * \brief Bibliothèque demoHelper.
 * \author Farès BELHADJ, amsi@ai.univ-paris8.fr
 * \date February 26, 2016
 */
#ifndef _GL4DH_H

#define _GL4DH_H

#include "gl4dp.h"
#include "gl4dhAnimeManager.h"

#endif
