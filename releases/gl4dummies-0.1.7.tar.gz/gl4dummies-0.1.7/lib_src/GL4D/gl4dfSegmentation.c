/*!\file gl4dfOpticalFlow.c
 *
 * \brief filres de segmentation d'images à partir d'une texture ou
 * l'écran vers une texture ou l'écran.
 *
 * \author Farès BELHADJ amsi@ai.univ-paris8.fr
 * \date April 21, 2016
 * 
 */
